Forex Chart AI (PWA)

របៀបដាក់ជា App លើ Home Screen
1) Host ឯកសារទាំងនេះលើ HTTPS (ឥតគិតថ្លៃ)៖
   - Netlify Drop: ចូល app.netlify.com/drop ហើយអូសថត forex-chart-ai ទៅដាក់
   - ឬ GitHub Pages / Cloudflare Pages
2) បើកតំណនោះលើទូរស័ព្ទ
   - iPhone (Safari): Share -> Add to Home Screen
   - Android (Chrome): menu -> Install app / Add to Home screen
3) បើកពី icon ហើយដាក់ Anthropic API key (រក្សាទុកតែក្នុងទូរស័ព្ទអ្នក)

ចំណាំ: មិនអាចដំណើរការជា PWA ពីឯកសារ local (file://) បានទេ ត្រូវការ HTTPS។
មិនមែនជាដំបូន្មានហិរញ្ញវត្ថុ។ សាកល្បងលើ demo ជាមុន។
